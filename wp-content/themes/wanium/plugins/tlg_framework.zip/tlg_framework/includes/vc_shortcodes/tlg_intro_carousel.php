<?php
/**
	DISPLAY SHORTCODE
**/	
if( !function_exists('tlg_framework_intro_carousel_shortcode') ) {
	function tlg_framework_intro_carousel_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'style' => 'intro-right',
			'nav' => '',
			'css_animation' => '',
		), $atts ) );
		$animation_class = tlg_framework_get_css_animation( $css_animation );
		if( 'box-top' == $style ) {
			if ( is_rtl() ) {
				$output = '<section class="'.esc_attr($animation_class).' p0"><div class="blog-carousel-rtl blog-carousel-detail three-columns">'. do_shortcode($content) .'</div></section>';
			} else {
				$output = '<section class="'.esc_attr($animation_class).' p0"><div class="blog-carousel blog-carousel-detail three-columns">'. do_shortcode($content) .'</div></section>';
			}
		} else {
			$output = '<div class="intro-carousel '.esc_attr($animation_class).' '.esc_attr($style).'">'. do_shortcode($content) .'</div>';
			if( substr_count( $content, '[tlg_intro_carousel_content' ) > 1 ) {
				if( 'arrow' == $nav ) {
					echo '<style type="text/css">.intro-carousel .owl-nav { position: absolute; top: 90px; left: 9.5%; right: auto; z-index: 2; }.intro-carousel.intro-left .owl-nav { position: absolute; left: auto; right: 9.5%;}.intro-carousel .owl-nav .owl-next {right: 0;}.intro-carousel .owl-nav .owl-next:before { content: "\e628"!important; color: #fff!important; font-size: 18px!important; }.bg-light .intro-carousel .owl-nav .owl-next:before, .bg-secondary .intro-carousel .owl-nav .owl-next:before { color: #222!important; }.intro-carousel .owl-nav .owl-prev {left: 0;}.intro-carousel .owl-nav .owl-prev:before { content: "\e629"!important; color: #fff!important; font-size: 18px!important; }.bg-light .intro-carousel .owl-nav .owl-prev:before, .bg-secondary .intro-carousel .owl-nav .owl-prev:before { content: "\e629"!important; color: #fff!important; font-size: 18px!important; }.intro-carousel .owl-nav .owl-prev:after { content: "/"; font-size: 20px; color: #fff; padding: 0 20px; line-height: 1; }.bg-light .intro-carousel .owl-nav .owl-prev:after, .bg-secondary .intro-carousel .owl-nav .owl-prev:after { color: #222!important; }</style>';
					if ( is_rtl() ) {
						$output .= '<script type="text/javascript">jQuery(document).ready(function() {jQuery(\'.intro-carousel\').owlCarousel({rtl: true, nav: true, navigation: true, dots: false, center: true, loop:true, responsive:{0:{items:1}}});});</script>';
					} else {
						$output .= '<script type="text/javascript">jQuery(document).ready(function() {jQuery(\'.intro-carousel\').owlCarousel({nav: true, navigation: true, dots: false, center: true, loop:true, responsive:{0:{items:1}}});});</script>';
					}
				} else {
					if ( is_rtl() ) {
						$output .= '<script type="text/javascript">jQuery(document).ready(function() {jQuery(\'.intro-carousel\').owlCarousel({rtl: true, nav: false, dots: true, center: true, loop:true, responsive:{0:{items:1}}});});</script>';
					} else {
						$output .= '<script type="text/javascript">jQuery(document).ready(function() {jQuery(\'.intro-carousel\').owlCarousel({nav: false, dots: true, center: true, loop:true, responsive:{0:{items:1}}});});</script>';
					}
				}
			}
		}
		
		return $output;
	}
	add_shortcode( 'tlg_intro_carousel', 'tlg_framework_intro_carousel_shortcode' );
}

/**
	DISPLAY SHORTCODE CHILD
**/	
if( !function_exists('tlg_framework_text_image_shortcode') ) {
	function tlg_framework_intro_carousel_content_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'layout' 		=> '',
			'image' 		=> '',
			'image_title' 	=> '',
			'title' 		=> '',
			'subtitle' 		=> '',
			'btn_link' 		=> '',
			'button_text' 	=> '',
			'icon' 			=> '',
			'button_icon_hover' => '',
			'button_layout'	=> 'btn btn-filled',
			'style' 		=> 'right',
			'hover' 		=> '',
			'customize_button' 	=> '',
			'btn_custom_layout' => 'btn',
			'btn_color' 		=> '',
			'btn_color_hover' 	=> '',
			'btn_bg' 			=> '',
			'btn_bg_hover' 		=> '',
			'btn_border' 		=> '',
			'btn_border_hover' 	=> '',
			'btn_bg_gradient' 		=> '',
			'btn_bg_gradient_hover' => '',
		), $atts ) );
		$custom_css 	= '';
		$custom_js 		= '';
		$link_prefix 	= '';
		$link_sufix 	= '';
		$column1 		= '';
		$column2 		= '';
		$element_id 	= uniqid('btn-');

		// BUILD STYLE
		$styles_button 	= '';

		if ( 'yes' == $customize_button ) {
			$button_layout 		= $btn_custom_layout;
			$btn_color 			= $btn_color 				? $btn_color : '#565656';
			$btn_bg 			= $btn_bg 					? $btn_bg : 'transparent';
			$btn_bg 			= $btn_bg_gradient 			? 'linear-gradient(to right,'.$btn_bg.' 0%,'.$btn_bg_gradient.' 100%)' : $btn_bg;
			$btn_border 		= $btn_border 				? $btn_border : 'transparent';
			$btn_color_hover 	= $btn_color_hover 			? $btn_color_hover : $btn_color;
			$btn_bg_hover 		= $btn_bg_hover 			? $btn_bg_hover : $btn_bg;
			$btn_bg_hover 		= $btn_bg_gradient_hover 	? 'linear-gradient(to right,'.$btn_bg_hover.' 0%,'.$btn_bg_gradient_hover.' 100%)' : $btn_bg_hover;
			$btn_border_hover 	= $btn_border_hover ? $btn_border_hover : $btn_border;

			$styles_button 		.= 'color:'.$btn_color.';background:'.$btn_bg.';border-color:'.$btn_border.';'.($btn_bg_gradient ? 'border: none!important;' : '');
			$custom_css 		.= '<style type="text/css" id="tlg-custom-css-'.$element_id.'">#'.$element_id.':hover{color:'.$btn_color_hover.'!important;background:'.$btn_bg_hover.'!important;border-color:'.$btn_border_hover.'!important;}</style>';
			$custom_js = "<script type=\"text/javascript\">jQuery(document).ready(function(){jQuery('head').append('".$custom_css."');});</script>";
		}

		// GET STYLE
		if ( ! empty( $styles_button ) ) {
			$style_button = 'style="' . esc_attr( $styles_button ) . '"';
		} else {
			$style_button = '';
		}
		
		// LINK
		$icon_hover = '';
		if( '' != $btn_link ) {
			$href = vc_build_link( $btn_link );
			if( $href['url'] !== "" ) {
				$target 		= isset($href['target']) && $href['target'] ? "target='".esc_attr($href['target'])."'" : 'target="_self"';
				$rel 			= isset($href['rel']) && $href['rel'] ? "rel='".esc_attr($href['rel'])."'" : '';

				if( $icon && 'yes' == $button_icon_hover ) {
					$icon_hover = '<i class="'.esc_attr($icon).'"></i>';
					$icon = '';
				}

				$link_prefix 	= '<a '.$style_button.' id="'.esc_attr($element_id).'" class="' .esc_attr( $button_layout. ' ' . $icon . ' ' .$hover ). ' btn-lg btn-sm-sm text-center mr-0 mb0 mt24" href= "'.esc_url($href['url']).'" '. $target.' '.$rel.'>';
				$link_sufix 	= '</a>';
			}
		}

		if( 'boxed' == $layout ) {
			$output = '<div class="boxed-intro-content zoom-hover bg-white">
							<div class="intro-image border-radious-top overflow-hidden">'.
								wp_get_attachment_image( $image, 'full', 0, array('class' => 'background-image') ).'
							</div>
							<div class="intro-content pt32 pb16 pl-32 pr-32">'.
								( $title ? '<h5 class="widgettitle dark-color mb16">'. htmlspecialchars_decode($title) .'</h5>' : '' ) .
								( $subtitle ? '<div class="widgetsubtitle mb16 uppercase-force ms-text">'. htmlspecialchars_decode($subtitle) .'</div>' : '' ) .
					           	'<div class="text-color mt24">'.do_shortcode($content) .'</div>'.
					           	( $button_text ? $link_prefix. $button_text.$icon_hover .$link_sufix : '' ).
							'</div>'.$custom_js.'
						</div>';
		} else {
			if( '2-1' == $layout ) {
				$column1 = 'col-md-8';
				$column2 = 'col-md-4';
			} elseif( '1-2' == $layout ) {
				$column1 = 'col-md-4';
				$column2 = 'col-md-8';
			} else {
				$column1 = 'col-md-6';
				$column2 = 'col-md-6';
			}
			$output = '<section class="image-square"><div class="'.esc_attr($column1).' image"><div class="background-content">'.
						wp_get_attachment_image( $image, 'full', 0, array('class' => 'background-image') ) .'</div></div>
					    <div class="'.esc_attr($column2).' content">'.
					    wp_get_attachment_image( $image_title, 'full', 0, array('class' => 'mb32 auto-width') ) .
					    ( $title ? '<h5 class="widgettitle mb16">'. htmlspecialchars_decode($title) .'</h5>' : '' ) .
						( $subtitle ? '<div class="widgetsubtitle">'. htmlspecialchars_decode($subtitle) .'</div>' : '' ) .
					    '<div>'.do_shortcode($content) .'</div>'.
					    ( $button_text ? $link_prefix. $button_text.$icon_hover .$link_sufix : '' ).$custom_js.
					    '</div></section>';
		}
		return $output;
	}
	add_shortcode( 'tlg_intro_carousel_content', 'tlg_framework_intro_carousel_content_shortcode' );
}

/**
	REGISTER SHORTCODE
**/
if( !function_exists('tlg_framework_intro_carousel_shortcode_vc') ) {
	function tlg_framework_intro_carousel_shortcode_vc() {
		vc_map( array(
		    'name' 						=> esc_html__( 'Intro Carousel' , 'tlg_framework' ),
		    'description' 				=> esc_html__( 'Create fancy carousel image', 'tlg_framework' ),
		    'icon' 						=> 'tlg_vc_icon_intro_carousel',
		    'base' 						=> 'tlg_intro_carousel',
		    'as_parent' 				=> array('only' => 'tlg_intro_carousel_content'),
		    'content_element' 			=> true,
		    'show_settings_on_create' 	=> false,
		    'js_view' 					=> 'VcColumnView',
		    'category' 					=> wp_get_theme()->get( 'Name' ) . ' ' . esc_html__( 'WordPress Theme', 'tlg_framework' ),
		    'params' 					=> array(
		    	array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Display style', 'tlg_framework' ),
					'param_name' 	=> 'style',
					'value' 		=> array(
						esc_html__( 'Full Width - Image right', 'tlg_framework' ) => 'intro-right',
						esc_html__( 'Full Width - Image left', 'tlg_framework' ) => 'intro-left',
						esc_html__( 'Boxed - Image top', 'tlg_framework' ) => 'box-top',
					),
					'description' 	=> esc_html__( 'Choose a display style for this intro box.', 'tlg_framework' )
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Navigation style', 'tlg_framework' ),
					'param_name' 	=> 'nav',
					'value' 		=> array(
						esc_html__( 'Dotted', 'tlg_framework' ) => '',
						esc_html__( 'Arrows', 'tlg_framework' ) => 'arrow',
					),
					'description' 	=> esc_html__( 'Choose a display style for this intro box.', 'tlg_framework' )
				),
				vc_map_add_css_animation(),
		    )
		) );
	}
	add_action( 'vc_before_init', 'tlg_framework_intro_carousel_shortcode_vc' );
}

/**
	REGISTER SHORTCODE CHILD
**/	
if( !function_exists('tlg_framework_intro_carousel_content_shortcode_vc') ) {
	function tlg_framework_intro_carousel_content_shortcode_vc() {
		$icons = tlg_framework_get_icons();
		vc_map( array(
		    'name'            => esc_html__( 'Intro Carousel Content', 'tlg_framework' ),
		    'description'     => esc_html__( 'Intro Carousel Content Element', 'tlg_framework' ),
		    'icon' 			  => 'tlg_vc_icon_intro_carousel',
		    'base'            => 'tlg_intro_carousel_content',
		    'category' 		  => wp_get_theme()->get( 'Name' ) . ' ' . esc_html__( 'WordPress Theme', 'tlg_framework' ),
		    'content_element' => true,
		    'as_child'        => array('only' => 'tlg_intro_carousel'),
		    'params'          => array(
		    	array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Layout', 'tlg_framework' ),
					'param_name' 	=> 'layout',
					'value' 		=> array(
						esc_html__( 'Full Width: 1/2 - 1/2', 'tlg_framework' )  => '1-1',
						esc_html__( 'Full Width: 2/3 - 1/3', 'tlg_framework' ) 	=> '2-1',
						esc_html__( 'Full Width: 1/3 - 2/3', 'tlg_framework' ) 	=> '1-2',
						esc_html__( 'Boxed layout', 'tlg_framework' ) 			=> 'boxed',
					),
			  	),
		    	array(
		    		'type' => 'attach_image',
		    		'heading' => esc_html__( 'Intro image', 'tlg_framework' ),
		    		'param_name' => 'image'
		    	),
		    	array(
		    		'type' 			=> 'attach_image',
		    		'heading' 		=> esc_html__( 'Image Above Title', 'tlg_framework' ),
		    		'param_name' 	=> 'image_title',
		    		'dependency' 	=> array('element' => 'layout','value' => array('1-1','2-1','1-2')),
		    	),
		    	array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title', 'tlg_framework' ),
					'param_name' 	=> 'title',
					'holder' 		=> 'div',
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Subtitle', 'tlg_framework' ),
					'param_name' 	=> 'subtitle',
					'holder' 		=> 'div',
				),
		    	array(
					'type' 			=> 'textarea_html',
					'heading' 		=> esc_html__( 'Content', 'tlg_framework' ),
					'param_name' 	=> 'content',
					'holder' 		=> 'div'
				),
				array(
					'type' 			=> 'vc_link',
					'heading' 		=> esc_html__( 'Button link', 'tlg_framework' ),
					'param_name' 	=> 'btn_link',
					'value' 		=> '',
			  	),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Button text', 'tlg_framework' ),
					'param_name' => 'button_text',
					'admin_label' 	=> true,
				),
				array(
	            	'type' 			=> 'tlg_icons',
	            	'heading' 		=> esc_html__( 'Button icon', 'tlg_framework' ),
	            	'description' 	=> esc_html__( 'Leave blank to hide icons.', 'tlg_framework' ),
	            	'param_name' 	=> 'icon',
	            	'value' 		=> tlg_framework_get_icons(),
	            ),
	            array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Enable icon hover?', 'tlg_framework' ),
					'description' 	=> esc_html__( 'Select \'Yes\' if you want to enable icon hover on this button.', 'tlg_framework' ),
					'class' 		=> '',
					'admin_label' 	=> false,
					'param_name' 	=> 'button_icon_hover',
					'value' 		=> array(
						esc_html__( 'No', 'tlg_framework' ) => '',
						esc_html__( 'Yes', 'tlg_framework' ) 	=> 'yes',
					),
			  	),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Button style', 'tlg_framework' ),
					'param_name' 	=> 'button_layout',
					'value' 		=> tlg_framework_get_button_layouts() + array( esc_html__( 'Link', 'tlg_framework' ) => 'btn-link' ),
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Button animation', 'tlg_framework' ),
					'param_name' 	=> 'hover',
					'value' 		=> tlg_framework_get_hover_effects(),
				),
				// Customize buttons - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		            array(
						'type' 			=> 'dropdown',
						'heading' 		=> esc_html__( 'Enable customize button?', 'tlg_framework' ),
						'description' 	=> esc_html__( 'Select \'Yes\' if you want to customize colors/layout for this button.', 'tlg_framework' ),
						'class' 		=> '',
						'admin_label' 	=> false,
						'param_name' 	=> 'customize_button',
						'value' 		=> array(
							esc_html__( 'No', 'tlg_framework' ) => '',
							esc_html__( 'Yes', 'tlg_framework' ) 	=> 'yes',
						),
						'group' 		=> esc_html__( 'Button Options', 'tlg_framework' ),
				  	),
				  	array(
						'type' 			=> 'dropdown',
						'heading' 		=> esc_html__( 'Button customize layout', 'tlg_framework' ),
						'param_name' 	=> 'btn_custom_layout',
						'value' 		=> array(
							esc_html__( 'Standard', 'tlg_framework' ) => 'btn',
							esc_html__( 'Rounded', 'tlg_framework' ) 	=> 'btn btn-rounded',
						),
						'group' 		=> esc_html__( 'Button Options', 'tlg_framework' ),
						'dependency' 	=> array('element' => 'customize_button','value' => array('yes')),
				  	),
		            array(
						'type' 			=> 'colorpicker',
						'heading' 		=> esc_html__( 'Button text color', 'tlg_framework' ),
						'description' 	=> esc_html__( 'Select color for button text.', 'tlg_framework' ),
						'param_name' 	=> 'btn_color',
						'group' 		=> esc_html__( 'Button Options', 'tlg_framework' ),
						'dependency' 	=> array('element' => 'customize_button','value' => array('yes')),
					),
					array(
						'type' 			=> 'colorpicker',
						'heading' 		=> esc_html__( 'Button background color', 'tlg_framework' ),
						'description' 	=> esc_html__( 'Select color for button background.', 'tlg_framework' ),
						'param_name' 	=> 'btn_bg',
						'group' 		=> esc_html__( 'Button Options', 'tlg_framework' ),
						'dependency' 	=> array('element' => 'customize_button','value' => array('yes')),
					),
					array(
						'type' 			=> 'colorpicker',
						'heading' 		=> esc_html__( 'Button background color (gradient)', 'tlg_framework' ),
						'description' 	=> esc_html__( 'To use combine with button background color above', 'tlg_framework' ),
						'param_name' 	=> 'btn_bg_gradient',
						'group' 		=> esc_html__( 'Button Options', 'tlg_framework' ),
						'dependency' 	=> array('element' => 'customize_button','value' => array('yes')),
					),
					array(
						'type' 			=> 'colorpicker',
						'heading' 		=> esc_html__( 'Button border color', 'tlg_framework' ),
						'description' 	=> esc_html__( 'Select color for button border.', 'tlg_framework' ),
						'param_name' 	=> 'btn_border',
						'group' 		=> esc_html__( 'Button Options', 'tlg_framework' ),
						'dependency' 	=> array('element' => 'customize_button','value' => array('yes')),
					),
					array(
						'type' 			=> 'colorpicker',
						'heading' 		=> esc_html__( 'Button HOVER text color', 'tlg_framework' ),
						'description' 	=> esc_html__( 'Select color for button hover text.', 'tlg_framework' ),
						'param_name' 	=> 'btn_color_hover',
						'group' 		=> esc_html__( 'Button Options', 'tlg_framework' ),
						'dependency' 	=> array('element' => 'customize_button','value' => array('yes')),
					),
					array(
						'type' 			=> 'colorpicker',
						'heading' 		=> esc_html__( 'Button HOVER background color', 'tlg_framework' ),
						'description' 	=> esc_html__( 'Select color for button hover background.', 'tlg_framework' ),
						'param_name' 	=> 'btn_bg_hover',
						'group' 		=> esc_html__( 'Button Options', 'tlg_framework' ),
						'dependency' 	=> array('element' => 'customize_button','value' => array('yes')),
					),
					array(
						'type' 			=> 'colorpicker',
						'heading' 		=> esc_html__( 'Button HOVER background color (gradient)', 'tlg_framework' ),
						'description' 	=> esc_html__( 'To use combine with button HOVER background color above', 'tlg_framework' ),
						'param_name' 	=> 'btn_bg_gradient_hover',
						'group' 		=> esc_html__( 'Button Options', 'tlg_framework' ),
						'dependency' 	=> array('element' => 'customize_button','value' => array('yes')),
					),
					array(
						'type' 			=> 'colorpicker',
						'heading' 		=> esc_html__( 'Button HOVER border color', 'tlg_framework' ),
						'description' 	=> esc_html__( 'Select color for button hover border.', 'tlg_framework' ),
						'param_name' 	=> 'btn_border_hover',
						'group' 		=> esc_html__( 'Button Options', 'tlg_framework' ),
						'dependency' 	=> array('element' => 'customize_button','value' => array('yes')),
					),
		    ),
		) );
	}
	add_action( 'vc_before_init', 'tlg_framework_intro_carousel_content_shortcode_vc' );
}

/**
	VC CONTAINER SHORTCODE CLASS
**/
if(class_exists('WPBakeryShortCodesContainer')) {
    class WPBakeryShortCode_tlg_intro_carousel extends WPBakeryShortCodesContainer {}
}
if(class_exists('WPBakeryShortCode')) {
    class WPBakeryShortCode_tlg_intro_carousel_content extends WPBakeryShortCode {}
}