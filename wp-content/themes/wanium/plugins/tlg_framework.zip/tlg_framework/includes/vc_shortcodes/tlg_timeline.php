<?php
/**
	DISPLAY SHORTCODE
**/		
if( !function_exists('tlg_framework_timeline_shortcode') ) {
	function tlg_framework_timeline_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'css_animation' => '',
		), $atts ) );
		$animation_class = tlg_framework_get_css_animation( $css_animation );
		return '<div class="'.esc_attr($animation_class).' timeline">'. do_shortcode($content) .'</div>';
	}
	add_shortcode( 'tlg_timeline', 'tlg_framework_timeline_shortcode' );
}

/**
	DISPLAY SHORTCODE CHILD
**/
if( !function_exists('tlg_timeline_content_shortcode') ) {
	function tlg_timeline_content_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'style' 	=> 'date',
			'icon' 			 => '',
			'timeline_link'  => '',
			'image' 	=> '',
			'text' 		=> '',
			'title' 	=> '',
			'datetime' 	=> '',
		), $atts ) );
		$timelineNode = '';
		if( ! $style || 'date' == $style ) {
			if( $datetime ) {
				$datetime 		= new DateTime($datetime);
				$timelineNode 	= '<div class="day">'. $datetime->format('d').'</div><div class="month">'. $datetime->format('M').' '. $datetime->format('Y') .'</div>';
			}
		} elseif ( 'text' == $style ) {
			$timelineNode = '<div class="month-text pt10">'.$text.'</div>';
		} elseif ( 'image' == $style ) {
			$image_src 		= wp_get_attachment_image_src($image, 'full');
			if( isset($image_src[0]) && $image_src[0] ) {
				$timelineNode = '<div class="image-round-100"><img src="'.$image_src[0].'" alt=="'.esc_html__( 'timeline-item', 'tlg_framework' ).'" /></div>';
			}
		}
		// LINK
		$link_prefix = $link_sufix = '';
		if( '' != $timeline_link ) {
			$href = vc_build_link( $timeline_link );
			if( $href['url'] !== "" ) {
				$target 		= isset($href['target']) && $href['target'] ? "target='".esc_attr($href['target'])."'" : 'target="_self"';
				$rel 			= isset($href['rel']) && $href['rel'] ? "rel='".esc_attr($href['rel'])."'" : '';
				
				$link_prefix 	= '<a class="inherit" href= "'.esc_url($href['url']).'" '. $target.' '.$rel.'>';
				$link_sufix 	= '</a>';
			}
		}
		$icon = !empty($icon) ? '<div class="text-right"><i class="'. esc_attr( $icon ) . ' ms-text"></i></div>' : '';
		return '<article class="timeline-item">
					<div class="timeline-date"><div class="linetime">'. $timelineNode . '</div></div>
					<div class="timeline-body"><div class="timeline-text">'.$link_prefix .
						( $title ? '<h4>'. htmlspecialchars_decode($title) .'</h4>' : '' ) . 
						wpautop(do_shortcode(htmlspecialchars_decode($content))) . $icon . $link_sufix .'
					</div></div>
				</article>';
	}
	add_shortcode( 'tlg_timeline_content', 'tlg_timeline_content_shortcode' );
}

/**
	REGISTER SHORTCODE
**/
if( !function_exists('tlg_framework_timeline_shortcode_vc') ) {
	function tlg_framework_timeline_shortcode_vc() {
		vc_map( array(
		    'name'                    	=> esc_html__( 'Timeline' , 'tlg_framework' ),
		    'description'             	=> esc_html__( 'Create a timeline module', 'tlg_framework' ),
		    'icon'				      	=> 'tlg_vc_icon_timeline',
		    'base'                    	=> 'tlg_timeline',
		    'as_parent'               	=> array('only' => 'tlg_timeline_content'),
		    'content_element'         	=> true,
		    'show_settings_on_create' 	=> true,
		    'js_view' 					=> 'VcColumnView',
		    'category' 					=> wp_get_theme()->get( 'Name' ) . ' ' . esc_html__( 'WordPress Theme', 'tlg_framework' ),
		    'params'          			=> array(
				vc_map_add_css_animation(),
		    ),
		) );
	}
	add_action( 'vc_before_init', 'tlg_framework_timeline_shortcode_vc' );
}

/**
	REGISTER SHORTCODE CHILD
**/
if( !function_exists('tlg_framework_timeline_content_shortcode_vc') ) {
	function tlg_framework_timeline_content_shortcode_vc() {
		vc_map( array(
		    'name'            			=> esc_html__( 'Timeline content', 'tlg_framework' ),
		    'description'     			=> esc_html__( 'Timeline content element', 'tlg_framework' ),
		    'icon' 			  			=> 'tlg_vc_icon_timeline',
		    'base'            			=> 'tlg_timeline_content',
		    'category' 		  			=> wp_get_theme()->get( 'Name' ) . ' ' . esc_html__( 'WordPress Theme', 'tlg_framework' ),
		    'content_element' 			=> true,
		    'as_child'        			=> array('only' => 'tlg_timeline'),
		    'params'          			=> array(
		    	array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Node display style', 'tlg_framework' ),
					'class' 		=> '',
					'admin_label' 	=> false,
					'param_name' 	=> 'style',
					'value' 		=> array(
						esc_html__( 'Datetime', 'tlg_framework' ) 	=> 'date',
						esc_html__( 'Text', 'tlg_framework' ) 		=> 'text',
						esc_html__( 'Image', 'tlg_framework' ) 		=> 'image',
					),
			  	),
			  	array(
					'type' 			=> 'vc_link',
					'heading' 		=> esc_html__( 'Timeline link', 'tlg_framework' ),
					'param_name' 	=> 'timeline_link',
					'value' 		=> '',
			  	),
			  	array(
					'type' => 'tlg_icons',
					'heading' => esc_html__( 'Click an Icon to choose', 'tlg_framework' ),
					'param_name' => 'icon',
					'value' => tlg_framework_get_icons(),
					'description' => esc_html__( 'Leave blank to hide icons.', 'tlg_framework' ),
				),
			  	array(
		    		'type' 			=> 'attach_image',
		    		'heading' 		=> esc_html__( 'Image', 'tlg_framework' ),
		    		'param_name' 	=> 'image',
		    		'admin_label' 	=> true,
		    		'dependency' 	=> array('element' => 'style', 'value' => array('image')),
		    	),
		    	array(
		    		'type' 			=> 'textfield',
		    		'heading' 		=> esc_html__( 'Text', 'tlg_framework' ),
		    		'param_name' 	=> 'text',
		    		'holder' 		=> 'div',
		    		'dependency' 	=> array('element' => 'style', 'value' => array('text')),
		    	),
		    	array(
			   		'type' 			=> 'tlg_datetime',
					'class' 		=> '',
					'heading' 		=> esc_html__( 'Datetime', 'tlg_framework' ),
					'param_name' 	=> 'datetime',
					'value' 		=> '', 
					'admin_label' 	=> true,
					'description' 	=> esc_html__( 'Date and time format (yyyy/mm/dd).', 'tlg_framework' ),
					'dependency' 	=> array('element' => 'style', 'value' => array('date')),
				),
		    	array(
		    		'type' 			=> 'textfield',
		    		'heading' 		=> esc_html__( 'Content Title', 'tlg_framework' ),
		    		'param_name' 	=> 'title',
		    		'holder' 		=> 'div'
		    	),
	            array(
	            	'type' 			=> 'textarea_html',
	            	'heading' 		=> esc_html__( 'Content Text', 'tlg_framework' ),
	            	'param_name' 	=> 'content'
	            ),
		    ),
		) );
	}
	add_action( 'vc_before_init', 'tlg_framework_timeline_content_shortcode_vc' );
}

/**
	VC CONTAINER SHORTCODE CLASS
**/
if( class_exists('WPBakeryShortCodesContainer') ) {
    class WPBakeryShortCode_tlg_timeline extends WPBakeryShortCodesContainer {}
}
if( class_exists('WPBakeryShortCode') ) {
    class WPBakeryShortCode_tlg_timeline_content extends WPBakeryShortCode {}
}